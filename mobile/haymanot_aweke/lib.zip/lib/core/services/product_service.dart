import 'package:haymanot_aweke/models/product.dart';

class ProductService {
  static final ProductService _instance = ProductService._internal();
  factory ProductService() => _instance;
  ProductService._internal();

  final List<Product> _products = [
    Product(
      name: "Christian Louboutin",
      category: "Women's high heels",
      price: 1000,
      imageUrl: "assets/images/Louboutin.jpg",
      description: "Christian Louboutin heels are handcrafted in Italy using premium Nappa leather.",
    ),
    Product(
      name: "Mach & Mach",
      category: "Women's high heels",
      price: 950,
      imageUrl: "assets/images/Mach & Mach.jpg",
      description: "Mach & Mach shoes are known for their signature double-bow crystal embellishments.",
    ),
  ];

  List<Product> getAllProducts() => List.unmodifiable(_products);
  
  Product? getProductByIndex(int index) {
    if (index >= 0 && index < _products.length) return _products[index];
    return null;
  }

  List<Product> searchProducts(String query) {
    if (query.isEmpty) return getAllProducts();
    return _products.where((product) {
      return product.name.toLowerCase().contains(query.toLowerCase()) ||
             product.category.toLowerCase().contains(query.toLowerCase());
    }).toList();
  }

  void createProduct(Product product) => _products.add(product);
  
  bool updateProduct(int index, Product updatedProduct) {
    if (index >= 0 && index < _products.length) {
      _products[index] = updatedProduct;
      return true;
    }
    return false;
  }
  
  bool deleteProduct(int index) {
    if (index >= 0 && index < _products.length) {
      _products.removeAt(index);
      return true;
    }
    return false;
  }
} 